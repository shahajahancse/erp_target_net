<?php
/* Translated by: M. Yuhdi & Ibrahim Yusuf */
	$lang['list_add'] 				= 'Tambah';
	$lang['list_actions'] 			= 'Pilihan';
	$lang['list_page'] 				= 'Halaman';
	$lang['list_paging_of'] 		= 'dari';
	$lang['list_displaying']		= 'Halaman {start} - {end} dari {results} total';
	$lang['list_filtered_from']		= '(filtered from {total_results} total entries)';
	$lang['list_show_entries']		= 'Ada {paging} data';
	$lang['list_no_items']			= 'Tidak ada item';
	$lang['list_zero_entries']		= 'Ditampilkan 0 - 0 dari 0 item';
	$lang['list_search'] 			= 'Cari';
	$lang['list_search_all'] 		= 'Cari Semua';
	$lang['list_clear_filtering'] 	= 'Hapus Filter';
	$lang['list_delete'] 			= 'Hapus';
	$lang['list_edit'] 				= 'Ubah';
	$lang['list_view'] 				= 'Lihat';
	$lang['list_paging_first'] 		= 'Awal';
	$lang['list_paging_previous'] 	= 'Sebelumnya';
	$lang['list_paging_next'] 		= 'Selanjutnya';
	$lang['list_paging_last'] 		= 'Terakhir';
	$lang['list_loading'] 			= 'Mohon Tunggu';

	$lang['form_edit'] 				= 'Ubah';
	$lang['form_view'] 				= 'Lihat';
	$lang['form_back_to_list'] 		= 'Kembali';
	$lang['form_update_changes'] 	= 'Simpan Perubahan';
	$lang['form_cancel'] 			= 'Batal';
	$lang['form_update_loading'] 	= 'Mohon Tunggu';
	$lang['update_success_message'] = 'Perubahan telah disimpan.';
	$lang['form_go_back_to_list'] 	= 'Kembali';

	$lang['form_add'] 				= 'Tambah';
	$lang['insert_success_message'] = 'Data telah ditambahkan.';
	$lang['form_or']				= 'atau';
	$lang['form_save'] 				= 'Simpan';
	$lang['form_insert_loading'] 	= 'Mohon Tunggu';

	$lang['form_upload_a_file'] 	= 'Unggah berkas';
	$lang['form_upload_delete'] 	= 'hapus';
	$lang['form_button_clear'] 		= 'Bersihkan';

	$lang['delete_success_message'] = 'Data telah dihapus.';
	$lang['delete_error_message'] 	= 'Terdapat kesalahan saat menghapus data.';

	/* Javascript messages */
	$lang['alert_add_form']			= 'Data telah dimasukkan tetapi belum disimpan.\\nApakah anda yakin ingin kembali?';
	$lang['alert_edit_form']		= 'Data telah diubah tetapi belum disimpan.\\nApakah anda yakin ingin kembali?';
	$lang['alert_delete']			= 'Apakah anda yakin ingin menghapus data?';

	$lang['insert_error']			= 'Terdapat kesalahan saat memasukkan data.';
	$lang['update_error']			= 'Terdapat kesalahan saat mengubah data.';

	$lang['crud_previous']			= 'Halaman sebelumnya';
	$lang['crud_next']				= 'Halaman selanjutnya';

	/* Added in version 1.2.1 */
	$lang['set_relation_title']		= 'Select {field_display_as}';
	$lang['list_record']			= 'Record';
	$lang['form_inactive']			= 'inactive';
	$lang['form_active']			= 'active';

	/* Added in version 1.2.2 */
	$lang['form_save_and_go_back']	= 'Simpan dan Kembali';
	$lang['form_update_and_go_back']= 'Simpan dan Kembali';

	/* Upload functionality */
	$lang['string_delete_file'] 	= "Menghapus file";
	$lang['string_progress'] 		= "Status: ";
	$lang['error_on_uploading'] 	= "Terdapat kesalahan pada saat upload.";
	$lang['message_prompt_delete_file'] 	= "Apakah anda yakin ingin menghapus file ini?";

	$lang['error_max_number_of_files'] 	= "Anda hanya dapat mengunggah 1 (satu) file pada satu waktu.";
	$lang['error_accept_file_types'] 	= "Anda tidak dapat mengunggah file dengan jenis ini.";
	$lang['error_max_file_size'] 		= "Ukuran file melebihi {max_file_size}.";
	$lang['error_min_file_size'] 		= "Anda tidak dapat mengunggah file kosong.";

	/* Added in version 1.3.1 */
	$lang['list_export'] 	= "Export";
	$lang['list_print'] 	= "Print";
	$lang['minimize_maximize'] = 'Minimize/Maximize';